month="January"
age=30
is_teacher = True

print(month)
print(age)
print(is_teacher)