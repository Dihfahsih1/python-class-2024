students=['John','Mary','Joy']

for student in students:
    print(student, end=" ")