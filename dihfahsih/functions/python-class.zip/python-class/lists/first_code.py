list1 = ["John", 2.5, True, 100]

list1[2] = 5


list1.append("Mary")
list1.insert(3,False)
print(list1)
def hello():
    print ("hello world")
hello()
