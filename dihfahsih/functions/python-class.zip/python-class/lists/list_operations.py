list1=['a', True, 3, 4.5, 3]
list2=[100,False, 'John', 0.0, True]

print("Original List One :", list1 )
print("Before updating index 2: ",list1[2])
newvalues='Mary'

list1[2]=newvalues
print("Updated list 1: ",list1)
print("After updating index 2",list1[2]) 

